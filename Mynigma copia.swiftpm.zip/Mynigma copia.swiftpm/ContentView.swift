import SwiftUI
import CoreMotion

struct ContentView: View {
/// GYROSCOPE
    let motionManager = CMMotionManager()
    let motionQueue = OperationQueue()
    
/// DOJO DOORS OPENING AND FADING ANIMATION
    @State var isBow = 0.0
    @State var isVanished = 1.0
    @State var shoji = 0
    
    
/// ICON TIP
    let timer = Timer.publish(every: 1, on: .main, in: .common).autoconnect()
    @State var value = 0
    @State var imageOpacity = 0.0
    
    
    var body: some View {
        NavigationView{
            ZStack{
                ArmorView()
                    .opacity(isBow)
                Color.black
                    .ignoresSafeArea().opacity(isVanished)
                
                HStack(spacing: 0.0){
                    Image("firstLeftShoji")
                        .resizable()
                        .offset(x: -CGFloat(shoji))
                    Image("firstRightShoji")
                        .resizable()
                        .offset(x: CGFloat(shoji))
                }
                VStack{
                    ZStack{
                        if isBow > 0.1{
                            
                            VStack(spacing: 200.0){
                                
                                Text("Please, complete the bow")
                                    .font(.title2)
                                    .foregroundColor(.white)
                                    .opacity(isVanished > 0.24 ? 1.0 : 0.0)
                                
                            }
                            
                        }
                        VStack{
                            Spacer()
                            Image("tiltIcon").aspectRatio(contentMode: .fit)
                                .padding(.bottom, 80)
                                .opacity(imageOpacity)
                            
                        }
                    }
                }
                
                
            }
            .onAppear{
                
                motionManager.startDeviceMotionUpdates(to: motionQueue) { (data: CMDeviceMotion?, error: Error?) in
                    guard let data = data else {
                        print("Error: \(error!)")
                        return
                    }
                    
                    let motion: CMAttitude = data.attitude
                    motionManager.deviceMotionUpdateInterval = 0.33
                    
                    DispatchQueue.main.async {
                        print(motion.pitch)
                    }
                    afterBow(motion: motion)
                    
                }
            }
            .onReceive(timer){ time in
                
                
                value += 1
                
                
                
                
                if isVanished <= 0{
                    withAnimation{
                        imageOpacity = 0.0
                    }
                }  else if value > 2 {
                    withAnimation{
                        imageOpacity = 1.0
                    }
                }
                
            }
            
            
            .navigationTitle("")
            .navigationBarHidden(true)
            .navigationBarBackButtonHidden(true)
            .statusBar(hidden: true)
            
        }
        .navigationViewStyle(StackNavigationViewStyle())
        
    }
    
/// ANIMATION AFTER BOWING
    func afterBow(motion: CMAttitude){
        if motion.pitch < 0.6 && motion.yaw < 0.5 && motion.yaw > -0.5 {
            if UIScreen.main.bounds.height < 1200{
                withAnimation{
                    isBow += 0.34
                    isVanished -= 0.34
                    shoji += 150
                }
            } else {
                withAnimation{
                    isBow += 0.25
                    isVanished -= 0.25
                    shoji += 150
                }
            }
        }
        
    }
}




