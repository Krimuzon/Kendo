//
//  DetailView.swift
//  Mynigma
//
//  Created by Cristian Amoddio on 12/04/22.
//

import SwiftUI


struct DetailView: View {    
/// INFORMATION TAKEN BY ARMORVIEW
    @Binding var touched: String
    
/// ARRAY OF ANY POSSIBLE RANDOM KIAI
    var kiaiArray = ["Hai", "Hei", "Ki", "Ku", "Tō", "Wata", "Ya", "Yo"]
    
    
    var body: some View {
        ZStack{
            Color.init(red: 0.06, green: 0.08, blue: 0.16).ignoresSafeArea()
            VStack{
                HStack{
                    Spacer()
                    Text(touched == "Zekken" ? "Samurai Academy" : touched)
                        .foregroundColor(.white)
                        .font(.largeTitle)
                        .bold()
                        .padding()
                    
                    if touched != "Zekken" && touched != "Tare"{
                        Button{
                            playSound(sound: touched, type: "m4a")
                            
                        }label:{
                            Image(systemName: "speaker.wave.2.fill")
                                .font(.system(size: 30))
                        }
                    }
                    
                    Spacer()
                }
                if touched == "Men"{
                    
                   
                        ScrollView{
                            VStack(alignment: .leading, spacing: 50.0){
                                
                                Text("_Men_ (面) is a sort of helmet used by kendō players to cover face, neck and shoulders which can be hit in three different parts: at the center, with the simple _zenshin men_, and in the upper left and upper right parts by performing _saiyu men_ (or _yoko men_).")                .fontWeight(.semibold)
                                
                                
                                
                                Image("men").resizable().aspectRatio(contentMode: .fit)
                                
                                
                                Text("Actually, there is one more hit kendō players can do on the men to make a point, _tsuki_; try to find it on the previous armor.")                .fontWeight(.semibold)
                                Spacer()
                                
                            }.padding(.horizontal, 100)
                                .padding()
                                .lineSpacing(20)
                                .font(.title)
                                .foregroundColor(.white)
                            
                        }
                        
                    
                    
                    
                } else if touched == "Tsuki"{
                    
                        ScrollView{
                            VStack(alignment: .leading, spacing: 50.0){
                                
                                Text("_Tsuki_ (突き) is a thrust to the throat of the opponent and for this reason is one of the most dangerous chop. As a matter of fact you need to reach at least the first level (_dan_) of kendō mastery to perform it. _Tsuki_ hits on the lower part of the men and it’s the only chop that is done by the tip (_kensen_) of the kendō sword (_shinai_).")                .fontWeight(.semibold)
                                
                                
                                Image("tsuki").resizable().aspectRatio(contentMode: .fit)
                                
                                
                                
                                
                                Spacer()
                                
                            }.padding(.horizontal, 100)
                                .padding()
                                .lineSpacing(20)
                                .font(.title)
                                .foregroundColor(.white)
                            
                        }
                    
                    
                } else if touched == "Dō"{
                    
                        ScrollView{
                            VStack(alignment: .leading, spacing: 50.0){
                                
                                Text("_Dō_ (胴) is a part of the armor that protects the player’s chest and stomach. You can make a regular point only by hitting the lower parts of the _dō_, both left and right, emulating a cut to the stomach. Usually, _dō_ is hit after having dodged a chop to _men_.")                .fontWeight(.semibold)
                                
                                
                                Image("do").resizable().aspectRatio(contentMode: .fit)
                                
                                
                                
                                
                                Spacer()
                                
                            }.padding(.horizontal, 100)
                                .padding()
                                .lineSpacing(20)
                                .font(.title)
                                .foregroundColor(.white)
                            
                            
                        }
                   
                    
                } else if touched == "Kote"{
                                            ScrollView{
                            VStack(alignment: .leading, spacing: 50.0){
                                
                                Text("_Kote_ (小手) are a particular kind of gloves used to cover hands and whrists and both right and left _kote_ can be hit but the latter only when the opponent raise the hands. The cut emulated by hitting _kote_ is meant to make the opponent unable to hold the sword.")                .fontWeight(.semibold)
                                
                                
                                Image("kote").resizable().aspectRatio(contentMode: .fit)
                                
                                
                                
                                
                                Spacer()
                                
                            }.padding(.horizontal, 100)
                                .padding()
                                .lineSpacing(20)
                                .font(.title)
                                .foregroundColor(.white)
                            
                        }
                   
                    
                    
                } else if touched == "Tare"{
                                            ScrollView{
                            VStack(alignment: .leading, spacing: 50.0){
                                
                               
                                Text("_Tare_ (垂れ) is the lowest part of the armor and protects groin and legs. However, if you are gonna hit it you won’t receive any point from the referee, it only has a protection function.")
                                    .fontWeight(.semibold)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                    
                                  
                                
                                Image("tare").resizable().aspectRatio(contentMode: .fit)
                                
                            
                                    
                                Text("_Tare_ is usually composed by 5 flaps, among which the central is covered by a tag (_zekken_) that identifies the name of the wearer and the dōjō or country they represent.\nOn the previous armor you can see my personal _zekken_, tap on it to learn more about my dōjō and my kendō experience! ") .fontWeight(.semibold)
                                    .frame(maxWidth: .infinity, alignment: .leading)
                                
                                
                                
                                
                                
                                
                                
                                Spacer()
                                
                            }.padding(.horizontal, 100)
                                .padding()
                                .lineSpacing(20)
                                .font(.title)
                                .foregroundColor(.white)
                        }
                    
                    
                    
                } else if touched == "Zekken"{
                    ScrollView{
                        VStack(alignment: .leading, spacing: 50.0){
                            
                            Image("zekken").resizable().aspectRatio(contentMode: .fit)
                            
                            Text("Hello everyone! My name is Cristian Amoddio and since Decemeber 2021 I’m a _kenshi_ (剣士, swordsman) at Samurai Academy in Naples.\nHere I’m learning, thanks to my _senpai_ (先輩, elder or more expert colleague/s) and _sensei_ (先生, master), the Japanese art of the sword: _kendō_ 剣道.\nI immediately fell in love with the dōjō and all the traditional habits related to this sport.")                .fontWeight(.semibold)
                            
                           
                            
                            Image("dojo1").resizable().aspectRatio(contentMode: .fit)
                            
                            Text("Despite Japanese people are commonly known as calm and silent people, _kendō_ practicers need to shout either when they are hitting their opponent or they want to get hyped. The precise term for this shout is _kiai_ (気合, shout for getting the right mood to deal with something or when performing an attacking move). Actually you can shout whatever you want but you need to express your _ki_ (気, spirit).")                .fontWeight(.semibold)
                            
                            HStack{
                                Spacer()
                                Text("Random kiai").foregroundColor(.white)
                                    .font(.title)
                                    .bold()
                                    .padding()
                                
                                Button{
                                    
                                    
                                    playSound(sound: kiaiArray.randomElement()!, type: "m4a")
                                    
                                }label:{
                                    Image(systemName: "speaker.wave.2.fill")
                                        .font(.system(size: 30))
                                        .foregroundColor(.accentColor)
                                }
                                Spacer()
                            }
                            
                            
                            Text("It’s me shouting the _kiai_ previously and this is me blurred because of my _kiai_.").fontWeight(.semibold)
                            
                            Image("kiai").resizable().aspectRatio(contentMode: .fit)
                            
                            Text("Although I graduated at Language University where I’ve studied Japanese, I haven’t gone to Japan yet but since then I’m enjoying this experience in my city enriching my Japanese culture knowledge. For this reason, I like to think that this sport is helping me being everytime one step closer to the country of my dreams.\nThis is me receiving from my master the 6th _kyū_ certificate (actually, the lowest level), but I'm looking forward to improving my skills and my level.\n_Ganbarimasu!_ (頑張ります, I’ll do my best). ").fontWeight(.semibold)
                            
                            
                            Image("dojo2").resizable().aspectRatio(contentMode: .fit)
                            
                            Text("To learn more about _kendō_ and my dōjō, follow 'Samurai Academy Naples' on Facebook")
                                .fontWeight(.heavy)
                                .font(.headline)
                                .padding(.bottom)
                            
                            
                            
                            
                            
                            
                           
                            
                        }.padding(.horizontal, 100)
                            .padding()
                            .lineSpacing(20)
                            .font(.title)
                            .foregroundColor(.white)
                        
                    }
                    
                }
                
                Spacer()
            }
        }
        .statusBar(hidden: true)
    }
}

struct DetailView_Previews: PreviewProvider {
    static var previews: some View {
        DetailView(touched: .constant("Tare"))
    }
}


