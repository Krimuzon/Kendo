//
//  ArmorView.swift
//  Mynigma
//
//  Created by Cristian Amoddio on 12/04/22.
//

import SwiftUI
import AVFoundation


/// AUDIO PLAYER FUNCTION
var audio: AVAudioPlayer!
func playSound(sound: String, type: String) {
    
    if let path = Bundle.main.path(forResource: sound, ofType: type) {
        do {
            audio = try AVAudioPlayer(contentsOf: URL(fileURLWithPath: path))
            audio.play()
            audio.setVolume(1.0, fadeDuration: 0.1)
        } catch {
            print ("ERRORINO")
        }
    }
}



struct ArmorView: View {
/// TRANSITION TO DETAILVIEW
    @State var change = false
    func moveToDetail(){
        change.toggle()
    }
    
/// DATA PASSING IN DETAILVIEW
    @State var touched = ""
    
    
    var body: some View {
        VStack{
            ZStack{
                VStack{
                    Image("bogu").resizable().aspectRatio(contentMode: .fit)
                    
                }.background(Image("parquet").ignoresSafeArea())
                VStack(spacing: 30.0){
                    NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                        Button (action: {
                            playSound(sound: "Men", type: "m4a")
                            touched = "Men"
                            moveToDetail()
                        },label: {
                            
                            Text("tap").opacity(0.0)
                            
                            
                                .frame(width: 260, height: 250)
                                .background(Color.clear )
                                .clipShape(Circle())
                            
                            
                        })
                    })
                    NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                        Button (action: {
                            playSound(sound: "Tsuki", type: "m4a")
                            touched = "Tsuki"
                            moveToDetail()
                            
                        },label: {
                            
                            Text("tap").opacity(0.0)
                            
                            
                                .frame(width: 150, height: 150)
                                .background(Color.clear )
                                .clipShape(Circle())
                            
                            
                        })
                    })
                    
                    
                    HStack(spacing: 60){
                        NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                            Button (action: {
                                playSound(sound: "Kote", type: "m4a")
                                touched = "Kote"
                                moveToDetail()
                            },label: {
                                
                                Text("tap").opacity(0.0)
                                
                                    .padding()
                                    .frame(width: 150, height: 150)
                                    .background(Color.clear )
                                    .clipShape(Circle())
                                
                                
                            })
                        })
                        
                        
                        NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                            Button (action: {
                                playSound(sound: "Dō", type: "m4a")
                                touched = "Dō"
                                moveToDetail()
                            },label: {
                                
                                Text("tap").opacity(0.0)
                                
                                
                                    .frame(width: 400, height: 400)
                                    .background(Color.clear )
                                    .clipShape(Circle())
                                
                                
                            })
                        })
                        
                        NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                            Button (action: {
                                playSound(sound: "Kote", type: "m4a")
                                touched = "Kote"
                                moveToDetail()
                            },label: {
                                
                                Text("tap").opacity(0.0)
                                
                                    .padding()
                                    .frame(width: 150, height: 150)
                                    .background(Color.clear )
                                    .clipShape(Circle())
                                
                                
                            })
                        })
                    }
                    HStack{
                        NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                            Button (action: {
                                touched = "Tare"
                                moveToDetail()
                            },label: {
                                
                                Text("tap").opacity(0.0)
                                
                                
                                    .frame(width: 180, height: 180)
                                    .background(Color.clear)
                                    .clipShape(Circle())
                                
                                
                            })
                        })
                        NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                            Button (action: {
                                touched = "Zekken"
                                moveToDetail()
                            },label: {
                                
                                Text("tap").opacity(0.0)
                                
                                
                                    .frame(width: 280, height: 280)
                                    .background(Color.clear)
                                    .clipShape(Circle())
                                
                                
                            })
                        })
                        NavigationLink(destination: DetailView(touched: $touched), isActive: $change, label: {
                            Button (action: {
                                touched = "Tare"
                                moveToDetail()
                            },label: {
                                
                                Text("tap").opacity(0.0)
                                
                                
                                    .frame(width: 180, height: 180)
                                    .background(Color.clear)
                                    .clipShape(Circle())
                                
                                
                            })
                        })
                    }
                }.opacity(1.0)
                    .background(Color.clear)
                
                    .padding(.horizontal, 60)
            }.padding()
        }
        .frame(width: UIScreen.main.bounds.width , height: UIScreen.main.bounds.height)
    }
}

struct ArmorView_Previews: PreviewProvider {
    static var previews: some View {
        ArmorView()
    }
}
